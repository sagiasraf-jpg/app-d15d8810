import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { base44 } from "@/api/base44Client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Alert, AlertDescription } from "@/components/ui/alert";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Shield, ShieldOff, Trash2, Search, Calendar, CheckCircle, XCircle, Key, Eye, EyeOff, Copy, Check, Phone, Edit2, AlertCircle, UserCog, Users, Plus, RefreshCw, X, Clock, Crown } from "lucide-react";
import { format } from "date-fns";
import { he } from "date-fns/locale";
import { Skeleton } from "@/components/ui/skeleton";

const groupLabels = {
  none: "ללא קבוצה",
  group1: "קבוצה 1",
  group2: "קבוצה 2",
  group3: "קבוצה 3",
  group4: "קבוצה 4"
};

const groupColors = {
  none: "bg-gray-100 text-gray-800 border-gray-300",
  group1: "bg-blue-100 text-blue-800 border-blue-300",
  group2: "bg-green-100 text-green-800 border-green-300",
  group3: "bg-purple-100 text-purple-800 border-purple-300",
  group4: "bg-orange-100 text-orange-800 border-orange-300"
};

const SYSTEM_OWNER_EMAIL = "sagiasraf@gmail.com";

export default function UserManagement({ currentAdminId }) {
  const [searchTerm, setSearchTerm] = useState("");
  const [deleteUserId, setDeleteUserId] = useState(null);
  const [roleChangeUserId, setRoleChangeUserId] = useState(null);
  const [roleChangeAction, setRoleChangeAction] = useState(null);
  const [roleChangeError, setRoleChangeError] = useState(null);
  const [resetPasswordUser, setResetPasswordUser] = useState(null);
  const [newPassword, setNewPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [copiedPassword, setCopiedPassword] = useState(false);
  const [editNameUser, setEditNameUser] = useState(null);
  const [newDisplayName, setNewDisplayName] = useState("");
  const [groupChangeUser, setGroupChangeUser] = useState(null);
  const [selectedGroup, setSelectedGroup] = useState("none");
  const [editPaymentUser, setEditPaymentUser] = useState(null);
  const [paymentFormData, setPaymentFormData] = useState({ total_forms: 0, paid_forms: 0, notes: "" });
  const [editingUnpaidId, setEditingUnpaidId] = useState(null);
  const [tempUnpaidValue, setTempUnpaidValue] = useState("");
  
  const queryClient = useQueryClient();

  const { data: users, isLoading } = useQuery({
    queryKey: ['all-users'],
    queryFn: () => base44.entities.User.list('-created_date'),
    initialData: [],
  });

  const { data: submissions } = useQuery({
    queryKey: ['all-submissions-count'],
    queryFn: () => base44.entities.LotterySelection.list(),
    initialData: [],
  });

  const { data: paymentRecords } = useQuery({
    queryKey: ['payment-records'],
    queryFn: () => base44.entities.UserPaymentRecord.list(),
    initialData: [],
  });

  const toggleRoleMutation = useMutation({
    mutationFn: async ({ userId, newRole, userName, adminName }) => {
      await base44.entities.User.update(userId, { role: newRole });
      
      await base44.entities.ActivityLog.create({
        user_id: userId,
        user_email: users.find(u => u.id === userId)?.email || "",
        user_name: userName,
        action: "profile_update",
        details: `שינוי תפקיד ל-${newRole === 'admin' ? 'מנהל' : 'משתמש רגיל'} על ידי ${adminName}`,
        changed_by_admin_id: currentAdminId,
        changed_by_admin_name: adminName
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-users'] });
      setRoleChangeUserId(null);
      setRoleChangeAction(null);
      setRoleChangeError(null);
    },
    onError: (error) => {
      console.error("Error changing role:", error);
      setRoleChangeError(error.message || "שגיאה בשינוי תפקיד");
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId) => {
      const user = users.find(u => u.id === userId);
      const currentAdmin = users.find(u => u.id === currentAdminId);
      
      await base44.entities.User.delete(userId);
      
      await base44.entities.ActivityLog.create({
        user_id: currentAdminId,
        user_email: currentAdmin?.email || "",
        user_name: currentAdmin?.full_name || "מנהל",
        action: "profile_update",
        details: `מחיקת משתמש: ${user?.full_name} (${user?.email}) על ידי ${currentAdmin?.full_name}`,
        changed_by_admin_id: currentAdminId,
        changed_by_admin_name: currentAdmin?.full_name || "מנהל"
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-users'] });
      setDeleteUserId(null);
      alert("✅ המשתמש נמחק בהצלחה!");
    },
    onError: (error) => {
      console.error("Error deleting user:", error);
      alert("❌ שגיאה במחיקת המשתמש");
    },
  });

  const updateDisplayNameMutation = useMutation({
    mutationFn: async ({ userId, displayName, adminName }) => {
      await base44.entities.User.update(userId, { display_name: displayName });
      
      await base44.entities.ActivityLog.create({
        user_id: userId,
        user_email: users.find(u => u.id === userId)?.email || "",
        user_name: displayName || users.find(u => u.id === userId)?.full_name || "",
        action: "profile_update",
        details: `שינוי שם תצוגה ל-"${displayName}" על ידי ${adminName}`,
        changed_by_admin_id: currentAdminId,
        changed_by_admin_name: adminName
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-users'] });
      setEditNameUser(null);
      setNewDisplayName("");
      alert("שם התצוגה עודכן בהצלחה! ✅");
    },
    onError: (error) => {
      console.error("Error updating display name:", error);
      alert("שגיאה בעדכון שם התצוגה");
    },
  });

  const updateGroupMutation = useMutation({
    mutationFn: async ({ userId, group, userName, adminName }) => {
      await base44.entities.User.update(userId, { group });
      
      await base44.entities.ActivityLog.create({
        user_id: userId,
        user_email: users.find(u => u.id === userId)?.email || "",
        user_name: userName,
        action: "profile_update",
        details: `שינוי קבוצה ל-${groupLabels[group]} על ידי ${adminName}`,
        changed_by_admin_id: currentAdminId,
        changed_by_admin_name: adminName
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['all-users'] });
      setGroupChangeUser(null);
      setSelectedGroup("none");
      alert("✅ הקבוצה עודכנה בהצלחה!");
    },
    onError: (error) => {
      console.error("Error updating group:", error);
      alert("❌ שגיאה בעדכון הקבוצה");
    },
  });

  const updatePaymentRecordMutation = useMutation({
    mutationFn: async ({ userEmail, userName, totalForms, paidForms, notes }) => {
      const existingRecords = await base44.entities.UserPaymentRecord.filter({ user_email: userEmail });
      
      if (existingRecords.length > 0) {
        await base44.entities.UserPaymentRecord.update(existingRecords[0].id, {
          user_email: userEmail,
          user_name: userName,
          total_forms_submitted: totalForms,
          paid_forms: paidForms,
          notes: notes || ""
        });
      } else {
        await base44.entities.UserPaymentRecord.create({
          user_email: userEmail,
          user_name: userName,
          total_forms_submitted: totalForms,
          paid_forms: paidForms,
          notes: notes || ""
        });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['payment-records'] });
      setEditPaymentUser(null);
      setPaymentFormData({ total_forms: 0, paid_forms: 0, notes: "" });
      setEditingUnpaidId(null);
      setTempUnpaidValue("");
      alert("✅ רשומת התשלום עודכנה בהצלחה!");
    },
    onError: (error) => {
      console.error("Error updating payment record:", error);
      alert("❌ שגיאה בעדכון רשומת התשלום");
    },
  });

  const generateRandomPassword = () => {
    const length = 12;
    const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%";
    let password = "";
    for (let i = 0; i < length; i++) {
      password += charset.charAt(Math.floor(Math.random() * charset.length));
    }
    return password;
  };

  const handleOpenPasswordReset = (user) => {
    setResetPasswordUser(user);
    setNewPassword(generateRandomPassword());
    setShowPassword(true);
    setCopiedPassword(false);
  };

  const handleOpenNameEdit = (user) => {
    setEditNameUser(user);
    setNewDisplayName(user.display_name || user.full_name || "");
  };

  const handleUpdateDisplayName = async () => {
    if (!newDisplayName.trim()) {
      alert("נא להזין שם תצוגה");
      return;
    }

    const currentAdmin = users.find(u => u.id === currentAdminId);
    await updateDisplayNameMutation.mutateAsync({
      userId: editNameUser.id,
      displayName: newDisplayName.trim(),
      adminName: currentAdmin?.full_name || "מנהל"
    });
  };

  const handleOpenGroupChange = (user) => {
    setGroupChangeUser(user);
    setSelectedGroup(user.group || "none");
  };

  const handleUpdateGroup = async () => {
    const currentAdmin = users.find(u => u.id === currentAdminId);
    await updateGroupMutation.mutateAsync({
      userId: groupChangeUser.id,
      group: selectedGroup,
      userName: groupChangeUser.full_name || groupChangeUser.email || "",
      adminName: currentAdmin?.full_name || "מנהל"
    });
  };

  const handleRoleChange = (user, action) => {
    if (user.email === SYSTEM_OWNER_EMAIL) {
      alert("🚫 לא ניתן לשנות תפקיד\n\nמשתמש זה הוא בעל המערכת ותמיד יישאר מנהל.\nלא ניתן להוריד אותו מתפקיד המנהל.");
      return;
    }
    
    setRoleChangeUserId(user.id);
    setRoleChangeAction(action);
    setRoleChangeError(null);
  };

  const handleConfirmRoleChange = async () => {
    const user = users.find(u => u.id === roleChangeUserId);
    const currentAdmin = users.find(u => u.id === currentAdminId);
    
    if (!user) return;

    if (user.email === SYSTEM_OWNER_EMAIL) {
      alert("🚫 לא ניתן לשנות תפקיד של בעל המערכת");
      setRoleChangeUserId(null);
      return;
    }

    const newRole = roleChangeAction === 'promote' ? 'admin' : 'user';
    
    await toggleRoleMutation.mutateAsync({
      userId: user.id,
      newRole,
      userName: user.full_name || user.email,
      adminName: currentAdmin?.full_name || "מנהל"
    });
  };

  const handleDeleteUser = (user) => {
    if (user.email === SYSTEM_OWNER_EMAIL) {
      alert("🚫 לא ניתן למחוק משתמש\n\nמשתמש זה הוא בעל המערכת ולא ניתן למחוק אותו.");
      return;
    }
    
    setDeleteUserId(user.id);
  };

  const handleConfirmDelete = async () => {
    if (!deleteUserId) return;
    await deleteUserMutation.mutateAsync(deleteUserId);
  };

  const getUserPaymentRecord = (userEmail) => {
    const record = paymentRecords.find(r => r.user_email === userEmail);
    if (record) {
      const totalForms = record.total_forms_submitted;
      const paidForms = record.paid_forms;
      const unpaidForms = totalForms - paidForms;
      return {
        totalForms,
        paidForms,
        unpaidForms: unpaidForms,
        notes: record.notes || "",
        recordId: record.id
      };
    }
    return null;
  };

  const handleStartEditUnpaid = (user, paymentRecord) => {
    setEditingUnpaidId(user.email);
    setTempUnpaidValue(paymentRecord.unpaidForms.toString());
  };

  const handleSaveUnpaid = async (user, paymentRecord) => {
    const newUnpaid = parseInt(tempUnpaidValue) || 0;
    const newPaidForms = paymentRecord.totalForms - newUnpaid;
    
    await updatePaymentRecordMutation.mutateAsync({
      userEmail: user.email,
      userName: user.display_name || user.full_name,
      totalForms: paymentRecord.totalForms,
      paidForms: newPaidForms,
      notes: paymentRecord.notes
    });

    setEditingUnpaidId(null);
    setTempUnpaidValue("");
  };

  const handleCancelEditUnpaid = () => {
    setEditingUnpaidId(null);
    setTempUnpaidValue("");
  };

  const handleOpenPaymentEdit = (user) => {
    setEditPaymentUser(user);
    const record = getUserPaymentRecord(user.email);
    
    if (record) {
      const actualRecord = paymentRecords.find(r => r.user_email === user.email);
      
      setPaymentFormData({
        total_forms: actualRecord?.total_forms_submitted || 0,
        paid_forms: actualRecord?.paid_forms || 0,
        notes: actualRecord?.notes || ""
      });
    } else {
      setPaymentFormData({
        total_forms: 0,
        paid_forms: 0,
        notes: ""
      });
    }
  };

  const handleSavePaymentRecord = async () => {
    if (!editPaymentUser) {
      alert("שגיאה: משתמש לא נבחר לעדכון תשלום.");
      return;
    }

    await updatePaymentRecordMutation.mutateAsync({
      userEmail: editPaymentUser.email,
      userName: editPaymentUser.display_name || editPaymentUser.full_name,
      totalForms: paymentFormData.total_forms,
      paidForms: paymentFormData.paid_forms,
      notes: paymentFormData.notes
    });
  };

  const handleCopyPassword = async () => {
    try {
      await navigator.clipboard.writeText(newPassword);
      setCopiedPassword(true);
      setTimeout(() => setCopiedPassword(false), 2000);
    } catch (error) {
      console.error("Error copying password:", error);
      alert("שגיאה בהעתקת הסיסמה");
    }
  };

  const handleOpenWhatsApp = (phone, user, password) => {
    const cleanPhone = phone.replace(/\D/g, '');
    const message = `שלום ${user.full_name}!

מנהל המערכת הגדיר עבורך סיסמה חדשה למערכת טופס לוטו 🎯

📧 *אימייל:* ${user.email}
🔑 *סיסמה:* ${password}

⚠️ *חשוב:*
1. השתמש בפרטים אלו להתחברות
2. מומלץ לשנות את הסיסמה לאחר הכניסה
3. שמור את הסיסמה במקום בטוח

🌐 כניסה למערכת: ${window.location.origin}

בהצלחה! 🎰`;

    const whatsappUrl = `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  const handleClosePasswordDialog = () => {
    setResetPasswordUser(null);
    setNewPassword("");
    setCopiedPassword(false);
  };

  const filteredUsers = users.filter(user =>
    !searchTerm ||
    user.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.display_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.nickname?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getUserSubmissionsCount = (userEmail) => {
    return submissions.filter(s => s.user_email === userEmail).length;
  };

  const hasUserSubmitted = (userEmail) => {
    return submissions.some(s => s.user_email === userEmail);
  };

  const getUserSubmissions = (userEmail) => {
    return submissions.filter(s => s.user_email === userEmail);
  };
  
  const getDisplayName = (user) => {
    return user.display_name || user.full_name;
  };
  
  const isSystemOwner = (userEmail) => {
    return userEmail === SYSTEM_OWNER_EMAIL;
  };
  
  const handleViewAsUser = (user) => {
    localStorage.setItem('impersonating_admin', JSON.stringify(currentAdminId));
    localStorage.setItem('impersonating_as', JSON.stringify(user));
    
    base44.entities.ActivityLog.create({
      user_id: currentAdminId,
      user_email: users.find(u => u.id === currentAdminId)?.email || "",
      user_name: users.find(u => u.id === currentAdminId)?.full_name || "מנהל",
      action: "profile_update",
      details: `כניסה כמשתמש: ${user.full_name} (${user.email})`
    });

    window.location.reload();
  };

  return (
    <>
      <Card className="border-2 border-purple-200 shadow-xl" dir="rtl">
        <CardHeader className="bg-gradient-to-r from-purple-50 to-pink-50 border-b-2 border-purple-200 p-4 md:p-6">
          <CardTitle className="text-lg md:text-2xl font-bold text-purple-900">ניהול משתמשים</CardTitle>
        </CardHeader>
        <CardContent className="p-3 md:p-6">
          <div className="mb-4 md:mb-6">
            <div className="relative">
              <Search className="absolute right-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="חיפוש משתמש..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pr-10 border-purple-300 focus:border-purple-500 text-sm"
              />
            </div>
          </div>

          <p className="text-gray-600 font-semibold mb-4 text-sm md:text-base">
            סה"כ {filteredUsers.length} משתמשים
          </p>

          <div className="md:hidden space-y-3">
            {isLoading ? (
              Array(3).fill(0).map((_, i) => (
                <Card key={i} className="border-2 border-purple-200">
                  <CardContent className="p-3">
                    <Skeleton className="h-32 w-full" />
                  </CardContent>
                </Card>
              ))
            ) : filteredUsers.length === 0 ? (
              <Card className="border-2 border-gray-200">
                <CardContent className="p-6 text-center text-gray-500 text-sm">
                  לא נמצאו משתמשים
                </CardContent>
              </Card>
            ) : (
              filteredUsers.map((user) => {
                const paymentRecord = getUserPaymentRecord(user.email);
                const isEditing = editingUnpaidId === user.email;
                const isOwner = isSystemOwner(user.email);
                
                return (
                  <Card key={user.id} className={`border-2 ${isOwner ? 'border-yellow-400 bg-gradient-to-br from-yellow-50 to-amber-50' : 'border-purple-200'}`}>
                    <CardContent className="p-3 space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="flex items-center gap-2">
                            <p className="font-bold text-purple-900 text-base">{getDisplayName(user)}</p>
                            {isOwner && (
                              <Crown className="w-4 h-4 text-yellow-600" />
                            )}
                          </div>
                          <p className="text-sm text-gray-600">{user.email}</p>
                          {isOwner && (
                            <p className="text-xs text-yellow-700 font-semibold mt-1">👑 בעל המערכת</p>
                          )}
                        </div>
                        {user.role === 'admin' ? (
                          <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                            <Shield className="w-3 h-3 ml-1" />
                            מנהל
                          </Badge>
                        ) : (
                          <Badge className="bg-gray-200 text-gray-700">
                            <Users className="w-3 h-3 ml-1" />
                            משתמש
                          </Badge>
                        )}
                      </div>

                      {user.nickname && (
                        <div className="flex items-center gap-2 text-sm">
                          <span className="text-gray-500">כינוי:</span>
                          <span className="font-semibold">{user.nickname}</span>
                        </div>
                      )}

                      {user.phone && (
                        <div className="flex items-center gap-2 text-sm">
                          <Phone className="w-3 h-3 text-gray-400" />
                          <span className="text-gray-600">{user.phone}</span>
                        </div>
                      )}

                      <Badge className={`text-xs ${groupColors[user.group || "none"]} border`}>
                        {groupLabels[user.group || "none"]}
                      </Badge>

                      {paymentRecord && (
                        <div className="bg-gradient-to-r from-amber-50 to-orange-50 border-2 border-amber-300 rounded-lg p-2">
                          <p className="text-xs font-bold text-amber-900 mb-1">💰 סטטוס תשלום:</p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-amber-800">טפסים שלא שולמו:</span>
                            {isEditing ? (
                              <div className="flex items-center gap-1">
                                <Input
                                  type="number"
                                  value={tempUnpaidValue}
                                  onChange={(e) => setTempUnpaidValue(e.target.value)}
                                  className="w-16 h-7 text-xs p-1"
                                />
                                <Button size="sm" onClick={() => handleSaveUnpaid(user, paymentRecord)} className="h-7 px-2">
                                  <Check className="w-3 h-3" />
                                </Button>
                                <Button size="sm" variant="outline" onClick={handleCancelEditUnpaid} className="h-7 px-2">
                                  <X className="w-3 h-3" />
                                </Button>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2">
                                <span className="text-lg font-black text-red-600">{paymentRecord.unpaidForms}</span>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleStartEditUnpaid(user, paymentRecord)}
                                  className="h-6 px-1"
                                >
                                  <Edit2 className="w-3 h-3" />
                                </Button>
                              </div>
                            )}
                          </div>
                        </div>
                      )}

                      <div className="grid grid-cols-2 gap-2">
                        <Button
                          onClick={() => handleOpenNameEdit(user)}
                          size="sm"
                          variant="outline"
                          className="text-xs h-8"
                        >
                          <Edit2 className="w-3 h-3 ml-1" />
                          שם
                        </Button>
                        <Button
                          onClick={() => handleOpenGroupChange(user)}
                          size="sm"
                          variant="outline"
                          className="text-xs h-8"
                        >
                          <Users className="w-3 h-3 ml-1" />
                          קבוצה
                        </Button>
                        <Button
                          onClick={() => handleRoleChange(user, user.role === 'admin' ? 'demote' : 'promote')}
                          size="sm"
                          variant="outline"
                          className="text-xs h-8"
                          disabled={isOwner}
                        >
                          {user.role === 'admin' ? <ShieldOff className="w-3 h-3 ml-1" /> : <Shield className="w-3 h-3 ml-1" />}
                          תפקיד
                        </Button>
                        <Button
                          onClick={() => handleOpenPaymentEdit(user)}
                          size="sm"
                          variant="outline"
                          className="text-xs h-8"
                        >
                          💰 תשלום
                        </Button>
                        <Button
                          onClick={() => handleDeleteUser(user)}
                          size="sm"
                          variant="outline"
                          className="text-xs h-8 border-red-300 text-red-600 hover:bg-red-50"
                          disabled={isOwner}
                        >
                          <Trash2 className="w-3 h-3 ml-1" />
                          מחק
                        </Button>
                        <Button
                          onClick={() => handleViewAsUser(user)}
                          size="sm"
                          className="bg-gradient-to-r from-cyan-500 to-blue-500 text-white text-xs h-8"
                        >
                          <Eye className="w-3 h-3 ml-1" />
                          כניסה
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </div>

          <div className="hidden md:block border-2 border-purple-200 rounded-lg overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="bg-gradient-to-r from-purple-100 to-pink-100">
                  <TableHead className="font-bold text-purple-900 text-sm p-4">שם</TableHead>
                  <TableHead className="font-bold text-purple-900 text-sm p-4">אימייל</TableHead>
                  <TableHead className="font-bold text-purple-900 text-sm p-4">תפקיד</TableHead>
                  <TableHead className="font-bold text-purple-900 text-sm p-4">קבוצה</TableHead>
                  <TableHead className="font-bold text-purple-900 text-sm p-4">טפסים שלא שולמו</TableHead>
                  <TableHead className="font-bold text-purple-900 text-center text-sm p-4">פעולות</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  Array(5).fill(0).map((_, i) => (
                    <TableRow key={i}>
                      <TableCell className="p-4"><Skeleton className="h-4 w-32" /></TableCell>
                      <TableCell className="p-4"><Skeleton className="h-4 w-40" /></TableCell>
                      <TableCell className="p-4"><Skeleton className="h-6 w-20" /></TableCell>
                      <TableCell className="p-4"><Skeleton className="h-6 w-24" /></TableCell>
                      <TableCell className="p-4"><Skeleton className="h-6 w-16" /></TableCell>
                      <TableCell className="p-4"><Skeleton className="h-8 w-full" /></TableCell>
                    </TableRow>
                  ))
                ) : filteredUsers.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-12 text-gray-500">
                      לא נמצאו משתמשים
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredUsers.map((user) => {
                    const paymentRecord = getUserPaymentRecord(user.email);
                    const isEditing = editingUnpaidId === user.email;
                    const isOwner = isSystemOwner(user.email);
                    
                    return (
                      <TableRow key={user.id} className={`transition-colors ${isOwner ? 'bg-gradient-to-r from-yellow-50 to-amber-50 hover:from-yellow-100 hover:to-amber-100' : 'hover:bg-purple-50'}`}>
                        <TableCell className="p-4">
                          <div>
                            <div className="flex items-center gap-2">
                              <p className="font-semibold text-purple-900">{getDisplayName(user)}</p>
                              {isOwner && (
                                <Crown className="w-4 h-4 text-yellow-600" />
                              )}
                            </div>
                            {user.nickname && (
                              <p className="text-xs text-gray-500">כינוי: {user.nickname}</p>
                            )}
                            {isOwner && (
                              <p className="text-xs text-yellow-700 font-semibold mt-1">👑 בעל המערכת</p>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-gray-700 p-4">{user.email}</TableCell>
                        <TableCell className="p-4">
                          {user.role === 'admin' ? (
                            <Badge className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
                              <Shield className="w-3 h-3 ml-1" />
                              מנהל
                            </Badge>
                          ) : (
                            <Badge className="bg-gray-200 text-gray-700">
                              <Users className="w-3 h-3 ml-1" />
                              משתמש
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell className="p-4">
                          <Badge className={`text-xs ${groupColors[user.group || "none"]} border`}>
                            {groupLabels[user.group || "none"]}
                          </Badge>
                        </TableCell>
                        <TableCell className="p-4">
                          {paymentRecord ? (
                            isEditing ? (
                              <div className="flex items-center gap-2">
                                <Input
                                  type="number"
                                  value={tempUnpaidValue}
                                  onChange={(e) => setTempUnpaidValue(e.target.value)}
                                  className="w-20 h-8 text-sm"
                                />
                                <Button size="sm" onClick={() => handleSaveUnpaid(user, paymentRecord)} className="h-8">
                                  <Check className="w-4 h-4" />
                                </Button>
                                <Button size="sm" variant="outline" onClick={handleCancelEditUnpaid} className="h-8">
                                  <X className="w-4 h-4" />
                                </Button>
                              </div>
                            ) : (
                              <div className="flex items-center gap-2">
                                <span className="text-2xl font-black text-red-600">{paymentRecord.unpaidForms}</span>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  onClick={() => handleStartEditUnpaid(user, paymentRecord)}
                                  className="h-8"
                                >
                                  <Edit2 className="w-4 h-4" />
                                </Button>
                              </div>
                            )
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </TableCell>
                        <TableCell className="p-4">
                          <div className="flex gap-2 justify-center flex-wrap">
                            <Button
                              onClick={() => handleOpenNameEdit(user)}
                              size="sm"
                              variant="outline"
                              className="text-xs"
                            >
                              <Edit2 className="w-3 h-3 ml-1" />
                              שם
                            </Button>
                            <Button
                              onClick={() => handleOpenGroupChange(user)}
                              size="sm"
                              variant="outline"
                              className="text-xs"
                            >
                              <Users className="w-3 h-3 ml-1" />
                              קבוצה
                            </Button>
                            <Button
                              onClick={() => handleRoleChange(user, user.role === 'admin' ? 'demote' : 'promote')}
                              size="sm"
                              variant="outline"
                              className="text-xs"
                              disabled={isOwner}
                            >
                              {user.role === 'admin' ? <ShieldOff className="w-3 h-3 ml-1" /> : <Shield className="w-3 h-3 ml-1" />}
                              תפקיד
                            </Button>
                            <Button
                              onClick={() => handleOpenPaymentEdit(user)}
                              size="sm"
                              variant="outline"
                              className="text-xs"
                            >
                              💰 תשלום
                            </Button>
                            <Button
                              onClick={() => handleDeleteUser(user)}
                              size="sm"
                              variant="outline"
                              className="text-xs border-red-300 text-red-600 hover:bg-red-50"
                              disabled={isOwner}
                            >
                              <Trash2 className="w-3 h-3 ml-1" />
                              מחק
                            </Button>
                            <Button
                              onClick={() => handleViewAsUser(user)}
                              size="sm"
                              className="bg-gradient-to-r from-cyan-500 to-blue-500 text-white text-xs"
                            >
                              <Eye className="w-3 h-3 ml-1" />
                              כניסה
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      <AlertDialog open={!!deleteUserId} onOpenChange={(open) => !open && setDeleteUserId(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-xl">
              <Trash2 className="w-6 h-6 text-red-600" />
              מחיקת משתמש
            </AlertDialogTitle>
            <AlertDialogDescription>
              <div className="space-y-3">
                <p className="text-base">
                  האם אתה בטוח שברצונך למחוק את המשתמש <strong>{users.find(u => u.id === deleteUserId)?.full_name}</strong>?
                </p>
                <Alert className="bg-red-50 border-red-300">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-900 text-sm">
                    <strong>⚠️ אזהרה:</strong> פעולה זו תמחק את המשתמש לצמיתות ולא ניתן יהיה לשחזר אותו!
                  </AlertDescription>
                </Alert>
                <Alert className="bg-orange-50 border-orange-300">
                  <AlertCircle className="h-4 w-4 text-orange-600" />
                  <AlertDescription className="text-orange-900 text-sm">
                    כל הנתונים של המשתמש (טפסים, תשלומים, וכו') יישארו במערכת אך המשתמש לא יוכל להתחבר.
                  </AlertDescription>
                </Alert>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setDeleteUserId(null)}>
              ביטול
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirmDelete}
              className="bg-red-600 hover:bg-red-700 font-bold"
            >
              🗑️ מחק משתמש
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={!!roleChangeUserId} onOpenChange={(open) => !open && setRoleChangeUserId(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-xl">
              {roleChangeAction === 'promote' ? (
                <>
                  <Shield className="w-6 h-6 text-purple-600" />
                  העלאה למנהל
                </>
              ) : (
                <>
                  <ShieldOff className="w-6 h-6 text-orange-600" />
                  הורדה למשתמש רגיל
                </>
              )}
            </AlertDialogTitle>
            <AlertDialogDescription>
              {roleChangeAction === 'promote' ? (
                <div className="space-y-2">
                  <p className="text-base">
                    האם אתה בטוח שברצונך להעלות את <strong>{users.find(u => u.id === roleChangeUserId)?.full_name}</strong> למנהל?
                  </p>
                  <Alert className="bg-purple-50 border-purple-300">
                    <AlertCircle className="h-4 w-4 text-purple-600" />
                    <AlertDescription className="text-purple-900 text-sm">
                      <strong>מנהל יוכל:</strong>
                      <ul className="list-disc mr-4 mt-1">
                        <li>לגשת לפאנל הניהול</li>
                        <li>לנהל משתמשים</li>
                        <li>לפרסם תוצאות</li>
                        <li>לנעול טפסים</li>
                      </ul>
                    </AlertDescription>
                  </Alert>
                </div>
              ) : (
                <div className="space-y-2">
                  <p className="text-base">
                    האם אתה בטוח שברצונך להוריד את <strong>{users.find(u => u.id === roleChangeUserId)?.full_name}</strong> למשתמש רגיל?
                  </p>
                  <Alert className="bg-orange-50 border-orange-300">
                    <AlertCircle className="h-4 w-4 text-orange-600" />
                    <AlertDescription className="text-orange-900 text-sm">
                      המשתמש יאבד גישה לפאנל הניהול
                    </AlertDescription>
                  </Alert>
                </div>
              )}
              {roleChangeError && (
                <Alert className="bg-red-50 border-red-300 mt-2">
                  <AlertCircle className="h-4 w-4 text-red-600" />
                  <AlertDescription className="text-red-900 text-sm">
                    {roleChangeError}
                  </AlertDescription>
                </Alert>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setRoleChangeUserId(null)}>
              ביטול
            </AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirmRoleChange}
              className={roleChangeAction === 'promote' ? "bg-purple-600 hover:bg-purple-700" : "bg-orange-600 hover:bg-orange-700"}
            >
              {roleChangeAction === 'promote' ? '⬆️ העלה למנהל' : '⬇️ הורד למשתמש'}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={!!editNameUser} onOpenChange={(open) => !open && setEditNameUser(null)}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl">
              <Edit2 className="w-5 h-5 text-purple-600" />
              עריכת שם תצוגה
            </DialogTitle>
            <DialogDescription>
              שנה את שם התצוגה של המשתמש במערכת
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>שם תצוגה חדש:</Label>
              <Input
                value={newDisplayName}
                onChange={(e) => setNewDisplayName(e.target.value)}
                placeholder="הזן שם תצוגה..."
                className="mt-2"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditNameUser(null)}>
              ביטול
            </Button>
            <Button onClick={handleUpdateDisplayName} className="bg-purple-600 hover:bg-purple-700">
              שמור
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!groupChangeUser} onOpenChange={(open) => !open && setGroupChangeUser(null)}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl">
              <Users className="w-5 h-5 text-purple-600" />
              שינוי קבוצה
            </DialogTitle>
            <DialogDescription>
              שנה את הקבוצה של {groupChangeUser?.full_name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>בחר קבוצה:</Label>
              <Select value={selectedGroup} onValueChange={setSelectedGroup}>
                <SelectTrigger className="mt-2">
                  <SelectValue placeholder="בחר קבוצה" />
                </SelectTrigger>
                <SelectContent>
                  {Object.entries(groupLabels).map(([value, label]) => (
                    <SelectItem key={value} value={value}>
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${groupColors[value].split(' ')[0]}`}></div>
                        <span>{label}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setGroupChangeUser(null)}>
              ביטול
            </Button>
            <Button onClick={handleUpdateGroup} className="bg-purple-600 hover:bg-purple-700">
              שמור
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!editPaymentUser} onOpenChange={(open) => !open && setEditPaymentUser(null)}>
        <DialogContent dir="rtl" className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-xl">
              💰 עריכת רשומת תשלום
            </DialogTitle>
            <DialogDescription>
              ניהול רשומת התשלום של {editPaymentUser?.display_name || editPaymentUser?.full_name}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>סה"כ טפסים שהוגשו:</Label>
              <Input
                type="number"
                value={paymentFormData.total_forms}
                onChange={(e) => setPaymentFormData({...paymentFormData, total_forms: parseInt(e.target.value) || 0})}
                className="mt-2"
              />
            </div>
            <div>
              <Label>טפסים ששולמו:</Label>
              <Input
                type="number"
                value={paymentFormData.paid_forms}
                onChange={(e) => setPaymentFormData({...paymentFormData, paid_forms: parseInt(e.target.value) || 0})}
                className="mt-2"
              />
            </div>
            <div className="bg-amber-50 border-2 border-amber-300 rounded-lg p-3">
              <p className="text-sm font-bold text-amber-900">
                טפסים שלא שולמו: <span className="text-2xl">{paymentFormData.total_forms - paymentFormData.paid_forms}</span>
              </p>
            </div>
            <div>
              <Label>הערות:</Label>
              <Input
                value={paymentFormData.notes}
                onChange={(e) => setPaymentFormData({...paymentFormData, notes: e.target.value})}
                placeholder="הערות על התשלום..."
                className="mt-2"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditPaymentUser(null)}>
              ביטול
            </Button>
            <Button onClick={handleSavePaymentRecord} className="bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600">
              שמור
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}